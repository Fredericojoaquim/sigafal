<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contratopagamentos extends Model
{
    use HasFactory;
    protected $table='contratopagamentos';
    protected $guarded=[];
    
}
