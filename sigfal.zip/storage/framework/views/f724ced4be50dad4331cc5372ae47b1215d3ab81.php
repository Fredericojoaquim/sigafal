<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <title>Comprovativ de pagamento</title>
    </head>
    <body>
        <style>
            *{
                margin:0;
                padding:0;
                border:0;
            }
        </style>

            <?php
                             /*$totais= (float)$total;
                                
                                $total=number_format($totais, 2,",",".") ;
                                //
                                $multa=(float)$multas;
                                $multas=number_format($multa, 2,",",".");*/
            
            ?>
        <?php for($i=0; $i<2; $i++): ?>
        <div style="width: 90%; margin: 0 auto; padding: 0;">
            
               
                <div style="float: left; width: 40% margin:0px; padding:0px;">
                    <div class="col-12" id="logotipo">
                       <img src="<?php echo e(public_path('images/nb.png')); ?>" alt="" style="width: 110px; height: 130px;  ">          
                    </div><br>

                    <div id="cabecario" style="margin-top:-50px; ">
                        <h6>N&B Comércio Geral, LDA</h6>  
                        <h6>RUA DIREITA-PARTE BRAÇO ZONA 20 <br> BAIRRO DANGEREUX <br>LUANDA-ANGOLA</h6>           
                    </div><br>
                    <div id="dados_enpresa">
                        <label for="">Telefone: 944337971</label><br>
                        <label for="">Iban:<strong> AO06005500003125130810136 </strong></label>
                    </div><br>
                    <br><br>
                </div>

                <div style="padding-top: 120px; width: 58%; float: left; padding-left: 2%">
                    <table style="width: 100%;">
                        <thead class="table-dark">
                            <tr style="background-color: black; color:white; height: 40px;">
                                <th style="font-size: 13px;">COMPROVATIVO DE PAGAMENTO DE CONTRATO</th>
                                <th>Nº: </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php if($i==0): ?> 
                                <td> ( Original )  </td>
                                <?php else: ?>
                                <td> ( Duplicado)  </td>
                                <?php endif; ?>
                                <td style="text-align: center;"><?php echo e($pg[0]->codigo); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <div style="">
                        <fieldset class="border p-2">
                            <div class="row">
                                <div class="col">
                                    <label for="">Exmo(s).Sr(s): <strong><?php echo e($pg[0]->nome); ?></strong></label><br>
                                    <label for="">NIF: <strong><?php echo e($pg[0]->nif); ?></strong></label><br>
                                    <label for="">Contacto:<strong> <?php echo e($pg[0]->telefone); ?> </strong></label><br>
                                </div>
                            </div>
                            
                        </fieldset>
                    </div>
                    
                    
                </div>

                <div style="clear: both; margin-top: 10px; ">
                    <div style="clear: both; ">
                        <h4 style="text-align:center; font-size: 15px;">DADOS DO PAGAMENTO</h4>
                        <table style="padding-top: 15px; width: 100%; ">
                            <thead style="background-color: black; color:white; height: 40px; border:none;">
                                <tr>
                                    <th>Id</th>
                                    <th>Id contrato</th>
                                    <th>Modo de Pagamento</th>
                                    <th>Valor Pago</th>
                                    <th>Data de Pagamento</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($pg)): ?>
                                    <?php $__currentLoopData = $pg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center"><?php echo e($p->codigo); ?></td>
                                    <td style="text-align: center"><?php echo e($p->id); ?></td>
                                    <td style="text-align: center"><?php echo e($p->modopagamento); ?></td>
                           
                                   
                               
                                   
                                   
                                   
                                    <?php 
                                    //formatando o valor que vem da BD no formato de dinheiro
                                    $valor = number_format($p->valor, 2,",",".");
                                    ?>
                                     <td ><?php echo e($valor); ?><</td>
                                     <td><?php echo e($p->data); ?></td>
                                 
                                 
                                </tr>
    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td ><strong>Total</strong></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td> <strong></strong> </td>
                                        <td><strong></strong></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        
                    </div>
                    
                </div>
                <p style="text-align: center">Processado por computador</p>
                <p style="text-align: center">Emitido em:<?php echo e(date('d/m/y H:i:s')); ?>  por: <?php echo e(Auth::user()->name); ?></p>
                <?php if($i==0): ?>
              
               <P style="width: 100%;">--------------------------------------------------------------------------------------------------------------------------------------</P>
                <?php endif; ?>
                <?php

                ?>
                
        </div>
      
        <?php endfor; ?>
       

      

        

       
    </body>
</html><?php /**PATH C:\Users\Asus\Desktop\sigfal\resources\views/relatorios/comprovativo_contrato.blade.php ENDPATH**/ ?>