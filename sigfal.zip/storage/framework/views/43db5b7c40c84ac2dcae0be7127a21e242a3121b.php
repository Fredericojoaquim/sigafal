


<?php $__env->startSection('title', 'Pagamentos'); ?>


<?php $__env->startSection('content'); ?>
<div class="section__content section__content--p30">
    <div class="container-fluid">

        <?php if($errors->any()): ?>
              
                         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                                <span class="badge badge-pill badge-danger">Erro</span>
                                <?php echo e($erro); ?> 
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                    

         <?php endif; ?>  

         <!-- -->

         <?php if(isset($erros)): ?>
              
                         <?php $__currentLoopData = $erros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                                <span class="badge badge-pill badge-danger">Erro</span>
                                <?php echo e($erro); ?> 
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
                    

         <?php endif; ?>  
         <!-- -->

         
                 <?php if(isset($sms)): ?>

                 <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
                     <span class="badge badge-pill badge-success">Success</span>
                     <?php echo e($sms); ?>

                     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                     </button>
                 </div>
 
                 <?php endif; ?>

                 <!-- mensagem quando não foi encontrado um cliente pelo nif-->
                 <?php if(session()->has('sms_erro')): ?>
                    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                        <span class="badge badge-pill badge-danger">Success</span>
                        <?php echo e(session()->get('sms_erro')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                 <?php endif; ?>

                 <div class="row mb-3">
                    <div class="col-md-12">
                        <div class="overview-wrap">
                            <h2 class="title-1">Pagamentos</h2>
                            <button class="au-btn au-btn-icon au-btn--blue" data-toggle="modal" data-target="#modalbuscar" >
                                <i class="zmdi zmdi-plus"></i>Pagamento</button>
                        </div>
                    </div>
                </div>

        <div class="myresponsivetable table-responsive table-responsive-data3 ">
        <table class="table" id="datatable">
            <thead class="table-dark">
           
                <tr>
                        <th>Id</th>
                        <th>Cliente</th>
                        <th>Nif</th>
                        <th>modo de pagamento</th>
                        <th>Mês Pago</th>
                        <th>Data</th> 
                        <th>Estado</th> 
                        <th>Acções</th>
                    </tr>
                
            </thead>
            <tbody>
                

                <?php 
                //formatando o valor que vem da BD no formato de dinheiro
               // $valor = number_format($s->multa, 2,",",".");
           
                ?>
            <?php if(isset($pg)): ?>
                  <?php $__currentLoopData = $pg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr >
                    <td><?php echo e($p->id); ?></td>
                    <td><?php echo e($p->cliente); ?></td>
                    <td><?php echo e($p->nif); ?></td>
                    <td><?php echo e($p->modo); ?></td>
                    <td><?php echo e($p->mes); ?></td>
                    <td><?php echo e($p->data); ?></td>
                    <td><?php echo e($p->estado); ?></td>
                    <td class="d-flex justify-content-center"> 
                        <button class="btn btn-primary btn-sm edita mr-1" id="">
                            <a class="bnEditar" href="<?php echo e(url("/pagamentos/show$p->idpagamento")); ?>">Alterar</a>
                        </button>

                        <button class="btn btn-secondary btn-sm editar  mr-1" id="">
                            <a class="bnEditar" href="<?php echo e(url("/dashboard/pagamentos/$p->idpagamento")); ?>">Detalhes</a>
                        </button>

                        <?php if($p->estado == 'não verificado'): ?>
                        <button class="btn btn-success btn-sm editar mr-1" id="$p->idpagamento" onclick="aprovar(<?php echo e($p->idpagamento); ?>)" data-toggle="modal"   data-target="#modalaprovar">
                           Aprovar
                        </button>
                    <?php else: ?>
                        <button disabled class="btn btn-warning btn-sm editar mr-1" id="$p->idpagamento">
                            Aprovar
                        </button>

                    <?php endif; ?>
                    </td>
                   

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
            <?php endif; ?> 
            </tbody>
          </table>
        </div>
    </div>
</div>

<!--Modal detalhes -->
<div class="modal fade" id="detalhes" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Detalhes de Pagamento</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                    <div class="row">

                            
                                        <div class="col-6">
                                            <label for="nome" class="control-label mb-1">Cliente: <?php echo e($detalhes[0]->cliente); ?></label>
    
                                        </div>

                                        <div class="col-6">
                                            <label for="nif" class="control-label mb-1">Usuário: <?php echo e($detalhes[0]->operador); ?></label>
                                        
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        
                                        <div class="col-6">
                                            <label for="morada" class="control-label mb-1">Mês Pago: <?php echo e($detalhes[0]->mes); ?></label>
                                            
                                        </div>
                                        <div class="col-6">
                                            <label for="morada" class="control-label mb-1">Valor: <?php echo e(number_format($detalhes[0]->valor, 2,",",".")); ?></label>
                                        </div>
                                        
                
                                        <div class="col-6">
                                            <label for="telefone" class="control-label mb-1">Ano: <?php echo e($detalhes[0]->ano); ?></label>
                                        </div>    
                                    </div>

                                    <div class="row">
                                        
                                        <div class="col-6">
                                            <label for="select" class=" form-control-label">Modo de Pagamento: <?php echo e($detalhes[0]->modo); ?></label>   
                                        </div>
                                        <div class="col-6">
                                            <label for="select" class=" form-control-label">Multa: <?php echo e(number_format($detalhes[0]->multa, 2,",",".")); ?></label>   
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="select" class=" form-control-label">Estado do Pagamento: <?php echo e($detalhes[0]->estado); ?> </label>   
                                        </div>
                                        <div class="col-6">
                                            <label for="select" class=" form-control-label">Banco: <?php echo e($detalhes[0]->banco); ?></label>   
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="select" class=" form-control-label">Referencia: <?php echo e($detalhes[0]->referencia); ?> </label>   
                                        </div>
                                        <div class="col-6">
                                            <label for="select" class=" form-control-label">Data do Registo: <?php echo e($detalhes[0]->data_pagamento); ?></label>   
                                        </div>
                                        <?php if($detalhes[0]->data_pagamento != $detalhes[0]->data_alteracao): ?>
                                            <div class="col-6">
                                                <label for="select" class=" form-control-label">Data do Registo: <?php echo e($detalhes[0]->data_alteracao); ?></label>   
                                            </div>
                                        <?php endif; ?>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>



<!-- modal aprovar-->
<div class="modal fade" id="modalaprovar" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger" id="smallmodalLabel">Atenção</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="mb-3">
                    Tem certeza que deseja aprovar este pagamento?
                </p>
                <form action="<?php echo e(url("/pagamentos/aprovar")); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" value="" name="id" id="id_aprovar">
                    <div class="float-right">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Não</button>
                        <button type="submit" class="btn btn-primary">Sim</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end modal small -->

<script>
   $(document).ready(function(){
       //   
        $('#detalhes').modal('show');
        var table=$('#datatable').DataTable();
    });
    function aprovar(id){
    $('#id_aprovar').val(id);
    }
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Desktop\sigfal\resources\views/admin/detalhes.blade.php ENDPATH**/ ?>