<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <div id="dados_enpresa">
        <p>Telefone: 944337971</p>
        <p>Iban:<strong> AO06005500003125130810136 </strong></p>
    </div>
   


   <div style="width: 100%;  height: 10px; margin: 0 auto;">
    <h3 style="text-align:center; font-size: 30px;">Extracto de Pagamentos</h3> <br>
   </div>


    <table>

        <thead>
            <tr>
                <th>Id</th>
                <th>Cliente</th>
                <th>Mês</th>
                <th>Ano</th>
                <th>Data Pagamento</th>
                <th>Valor</th>
                <th>Multa</th>
              
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                               
                <td><?php echo e($p->idpagamento); ?></td>
                <td><?php echo e($p->cliente); ?></td>
                <td><?php echo e($p->mes); ?></td>
                <td><?php echo e($p->ano); ?></td>
                <td style="color: red;"><?php echo e($p->valor); ?></td>
                <td><?php echo e($p->multa); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</body>
</html><?php /**PATH C:\Users\Asus\Desktop\sigfal\resources\views/relatorios/exemplo.blade.php ENDPATH**/ ?>