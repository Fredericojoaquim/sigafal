<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <title>Relatório</title>
    </head>
    <body>
        <style>
            *{
                margin:0;
                padding:0;
                border:0;
            }
        </style>

            <?php
                             $totais= (float)$total;
                                
                                $total=number_format($totais, 2,",",".") ;
                                //
                                $multa=(float)$multas;
                                $multas=number_format($multa, 2,",",".");
            
            ?>
        <?php for($i=0; $i<2; $i++): ?>
        <div style="width: 90%; margin: 0 auto; padding: 0;">
            
               
                <div style="float: left; width: 40% margin:0px; padding:0px;">
                    <div class="col-12" id="logotipo">
                       <img src="<?php echo e(public_path('images/nb.png')); ?>" alt="" style="width: 110px; height: 130px;  ">          
                    </div><br>

                    <div id="cabecario" style="margin-top:-50px; ">
                        <h6>N&B Comércio Geral, LDA</h6>  
                        <h6>RUA DIREITA-PARTE BRAÇO ZONA 20 <br> BAIRRO DANGEREUX <br>LUANDA-ANGOLA</h6>           
                    </div><br>
                    <div id="dados_enpresa">
                        <label for="">Telefone: 944337971</label><br>
                        <label for="">Iban:<strong> AO06005500003125130810136 </strong></label>
                    </div><br>
                    <br><br>
                </div>

                <div style="padding-top: 120px; width: 58%; float: left; padding-left: 2%">
                    <table style="width: 100%;">
                        <thead class="table-dark">
                            <tr style="background-color: black; color:white; height: 40px;">
                                <th>COMPROVATIVO DE PAGAMENTO</th>
                                <th>Nº: </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php if($i==0): ?> 
                                <td> ( Original )  </td>
                                <?php else: ?>
                                <td> ( Duplicado)  </td>
                                <?php endif; ?>
                                <td style="text-align: center;"><?php echo e($pg[0]->id); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <div>
                        <fieldset class="border p-2">
                            <div class="row">
                                <div class="col">
                                    <label for="">Exmo(s).Sr(s): <strong><?php echo e($pg[0]->cliente); ?></strong></label><br>
                                    <label for="">NIF: <strong><?php echo e($pg[0]->nif); ?></strong></label><br>
                                    <label for="">Endereço:<strong> <?php echo e($pg[0]->morada); ?> </strong></label><br>
                                    <label for="">PT:<strong> <?php echo e($pg[0]->pt); ?> </strong></label><br>
                                    <label for="">Contribuinte PT</label>
                                </div>
                            </div>
                            
                        </fieldset>
                    </div>
                    
                    <label for="">Processado por Computador</label>
                </div>

                <div style="clear: both; ">
                    <table style="padding-top: 15px; width: 100%; ">
                        <thead style="background-color: black; color:white; height: 40px; border:none;">
                            <tr>
                                <th>Id</th>
                                <th>Mês</th>
                                <th>Ano</th>
                                <th>Data Pagamento</th>
                                <th>Valor</th>
                                <th>Multa</th>
                              
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($pg)): ?>
                                <?php $__currentLoopData = $pg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->idpagamento); ?></td>
                                <td><?php echo e($p->mes); ?><</td>
                                <td><?php echo e($p->ano); ?><</td>
                                <td><?php echo e($p->data); ?><</td>
                               
                                <?php 
                                //formatando o valor que vem da BD no formato de dinheiro
                                $valor = number_format($p->valor, 2,",",".");
                                $multa = number_format($p->multa, 2,",",".");
                                ?>
                                 <td ><?php echo e($valor); ?></td>
                                 <td ><?php echo e($multa); ?></td>
                             
                            </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php
                                    
                                    ?>

                                    <?php if($i==1): ?>
                                     <?php
                                     //dd($total);
                                     ?>
                                    <?php endif; ?>

                                    
                                    <td ><strong>Total</strong></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td> <strong> <?php echo e(number_format($totais, 2,",",".")); ?></strong> </td>
                                    <td><strong><?php echo e($multas); ?></strong></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                </div>
                <br>
                 <br>
                <p style="text-align: center">Emitido em:<?php echo e(date('d/m/y H:i:s')); ?>  por: <?php echo e(Auth::user()->name); ?></p>
                <?php if($i==0): ?>
                <br><br><br>
               <P style="width: 100%;">--------------------------------------------------------------------------------------------------------------------------------------</P>
                <?php endif; ?>
        </div>
      
        <?php endfor; ?>
       

      

        

       
    </body>
</html><?php /**PATH C:\Users\Asus\Desktop\sigfal\resources\views/relatorios/fatura.blade.php ENDPATH**/ ?>