<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ultimopagamento extends Model
{
    use HasFactory;
    protected $table='ultimopagamentos';
    protected $guarded=[];

}
